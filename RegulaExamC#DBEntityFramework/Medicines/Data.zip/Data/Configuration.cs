﻿using AutoMapper;

namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=CECO\SQLEXPRESS;Database=Medicines;User Id=sa;Password=1234;TrustServerCertificate=True;";

        public static Mapper getMapper() 
        {
            var cfg = new MapperConfiguration(c => c.AddProfile<MedicinesProfile>());
            return new Mapper(cfg);
        }
    }
}
