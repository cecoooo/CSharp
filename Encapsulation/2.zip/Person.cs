﻿using PersonsInfo;

public class Person
{
    public string FirstName { get; private set; }
    public string LastName { get; private set; }
    public int Age { get; private set; }
    public decimal Salary { get; private set; }
    public Person() 
    {
    
    }
    public Person(string fname, string lname, int age, decimal salary) 
    {
        this.FirstName = fname;
        this.LastName = lname;
        this.Age = age;
        this.Salary = salary;
    }
    public void IncreaseSalary(decimal percentage) 
    {
        var income = 0m;
        if (this.Age < 30) 
            income = this.Salary * (percentage / 200);
        else
            income = this.Salary * (percentage / 100);
        this.Salary += income;
    }
    public override string ToString() 
    {
        return $"{this.FirstName} {this.LastName} receives {this.Salary:f2} leva.";
    }
}