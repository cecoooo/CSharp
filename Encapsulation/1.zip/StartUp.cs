﻿using System;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main()
        {
            var person = new Person("Ivan", "Gomez", 21);
            Console.WriteLine(person.ToString());
        }
    }
}
