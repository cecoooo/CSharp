﻿using System;
using System.Collections.Generic;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main()
        {
            //var n = int.Parse(Console.ReadLine());
            //var persons = new List<Person>();
            //for (int i = 0; i < n; i++)
            //{
            //    var command = Console.ReadLine().Split(' ');
            //    var person = new Person(command[0], 
            //        command[1], 
            //        int.Parse(command[2]), 
            //        decimal.Parse(command[3]));
            //    persons.Add(person);
            //}
            //var percentage = decimal.Parse(Console.ReadLine());
            //persons.ForEach(x => x.IncreaseSalary(percentage));
            //persons.ForEach(x => Console.WriteLine(x.ToString()));
            var person = new Person("ga", "dd", -20, 314);
        }
    }
}
