﻿using System;
using System.Collections.Generic;
using System.Text;
using Cars;

public interface IElectricCar
{
    public int Battery { get; set; }
}