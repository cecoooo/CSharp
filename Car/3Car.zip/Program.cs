﻿using System;
namespace CarManufacturer

{
    public class StartUp
    {
        static void Main()
        {
            //Car car = new Car();
            //car.Make = "BMW";
            //car.Model = "X6";
            //car.Year = 2002;
            //car.FuelQuantity = 200;
            //car.FuelConsumption = 0.02;
            //car.Drive(2000);
            //car.Drive(1000);
            //Console.WriteLine(car.WhoAmI());
            //Console.WriteLine();

            //Car carr = new Car("bmw", "x6", 2001);
            //Console.WriteLine(carr.Make);
            //Console.WriteLine(carr.Model);
            //Console.WriteLine(carr.Year);
            //Console.WriteLine(carr.FuelQuantity);
            //Console.WriteLine(carr.FuelConsumption);
            //Console.WriteLine();

            //Car carrr = new Car("Audi", "A3", 2005, 100, 0.1);
            //Console.WriteLine(carrr.Make);
            //Console.WriteLine(carrr.Model);
            //Console.WriteLine(carrr.Year);
            //Console.WriteLine(carrr.FuelQuantity);
            //Console.WriteLine(carrr.FuelConsumption);
            //Console.WriteLine();

        }
    }
}
