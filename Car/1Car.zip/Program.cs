﻿using System;
namespace CarManufacturer

{
    public class StartUp
    {
        static void Main()
        {
            Car car = new Car();
            car.Make = "Golf";
            car.Model = "Kombi";
            car.Year = 2001;
            Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");
        }
    }
}
