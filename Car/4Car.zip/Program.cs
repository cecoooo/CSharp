﻿using System;
using System.Linq;

namespace CarManufacturer

{
    public class StartUp
    {
        static void Main()
        {
            //Car car = new Car();
            //car.Make = "BMW";
            //car.Model = "X6";
            //car.Year = 2002;
            //car.FuelQuantity = 200;
            //car.FuelConsumption = 0.02;
            //car.Drive(2000);
            //car.Drive(1000);
            //Console.WriteLine(car.WhoAmI());
            //Console.WriteLine();

            //Car carr = new Car("bmw", "x6", 2001);
            //Console.WriteLine(carr.Make);
            //Console.WriteLine(carr.Model);
            //Console.WriteLine(carr.Year);
            //Console.WriteLine(carr.FuelQuantity);
            //Console.WriteLine(carr.FuelConsumption);
            //Console.WriteLine();

            //Car carrr = new Car("Audi", "A3", 2005, 100, 0.1);
            //Console.WriteLine(carrr.Make);
            //Console.WriteLine(carrr.Model);
            //Console.WriteLine(carrr.Year);
            //Console.WriteLine(carrr.FuelQuantity);
            //Console.WriteLine(carrr.FuelConsumption);
            //Console.WriteLine();


            Tire[] tires = new Tire[4]
            {
                new Tire(2019, 2.5),
                new Tire(2018, 2.4),
                new Tire(2017, 2.5),
                new Tire(2019, 2.6)
            };

            Engine engine = new Engine(100, 500);

            Car car = new Car("BMW", "x6", 2001, 100, 0.1, engine, tires);

            Console.WriteLine($"Make: {car.Make}\n" +
                $"Model: {car.Model}\n" +
                $"Year: {car.Year}\n" +
                $"Fuel Quantity: {car.FuelQuantity}\n" +
                $"Fuel Consumtion: {car.FuelConsumption}\n" +
                $"Engine info => Horse power: {car.Engine.HorsePower}\n" +
                $"            => Cubics: {car.Engine.CubicCapacity}\n" +
                $"Tires info => Year: {string.Join(", ", car.Tires.Select(x => x.Year))}\n" +
                $"           => Pressure: {string.Join(", ", car.Tires.Select(x => x.Pressure))}");
        }
    }
}
