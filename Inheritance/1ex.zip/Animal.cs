﻿using System;
using System.Collections.Generic;
using System.Text;
using Farm;

public class Animal
{
    public void Eat() 
    {
        Console.WriteLine("eating...");
    }
}
