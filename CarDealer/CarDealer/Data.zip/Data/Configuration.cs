﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=CECO\SQLEXPRESS;Database=CarDealer;User Id=sa;Password=1234;TrustServerCertificate=True;";
    }
}
