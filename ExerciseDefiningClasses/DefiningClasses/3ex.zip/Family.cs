﻿using System;
using System.Collections.Generic;
using System.Text;
using DefiningClasses;
using System.Linq;

public class Family
{
    private List<Person> list = new List<Person>();

    public List<Person> List 
    { 
        get { return list; }
        set { list = value; }
    }

    public void AddMember(Person person) 
    {
        this.list.Add(person);
    }

    public Person GetOldestMember()
    {
        Person p = new Person();
        int max = int.MinValue;
        for (int i = 0; i < this.List.Count; i++)
        {
            if (list[i].Age > max) 
            {
                max = list[i].Age;
                p = list[i];
            }
        }
        return p;
    }
}