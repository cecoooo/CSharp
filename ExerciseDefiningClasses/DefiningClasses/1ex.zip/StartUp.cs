﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Peter";
            p1.Age = 20;
            Console.WriteLine(p1.Name+"\n"+p1.Age);
        }
    }
}
