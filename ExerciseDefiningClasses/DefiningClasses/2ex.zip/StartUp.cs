﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            Console.WriteLine(p1.Name+"\n"+p1.Age);
        }
    }
}
